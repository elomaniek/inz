const express = require('express');
const settings = require('./settings');
const nms = require('./media-server');

const app = express();
app.use(express.json());

const nmsInstance = nms.run(settings.get().archive);

app.get('/settings', (_, res) => {
  res.status(200).send(settings.get());
});

app.post('/settings', (req, res) => {
  const currentSettings = settings.get();
  const filteredChanges = Object.entries(req.body)
    .filter(([key]) => {
      if (currentSettings[key] === undefined) {
        return false;
      }

      return true;
    })
    .reduce((agg, curr) => {
      agg[curr[0]] = curr[1];
      return agg;
    }, {});

  if (currentSettings.archive !== filteredChanges.archive) {
    if (filteredChanges.archive) {
      nmsInstance.startArchiving();
      console.log('[!!!] Archiving started!');
    } else {
      nmsInstance.stopArchiving();
      console.log('[!!!] Archiving stopped!');
    }
  }

  settings.set(filteredChanges);
  res.status(200).send();
});

app.listen(8080);
console.info('Up and running, listening on 8080');
